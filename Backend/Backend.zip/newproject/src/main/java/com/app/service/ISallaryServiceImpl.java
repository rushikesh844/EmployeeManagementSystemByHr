package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojo.Attendance;
import com.app.pojo.ComputedSal;
import com.app.pojo.Employee;
import com.app.pojo.ExtraWork;
import com.app.pojo.Sallary;
import com.app.repository.IAttendanceRepository;
import com.app.repository.IExtraWorkRepository;
import com.app.repository.ISallaryRepository;
@Service
@Transactional
public class ISallaryServiceImpl implements ISallaryService {

	@Autowired
	private ISallaryRepository repos;
	@Autowired
	private IAttendanceRepository arepos;
	@Autowired
	private IExtraWorkRepository erepos;
	
	public List<Sallary> findAllSalaryDetails() {
		System.out.println("in service impl");
		List<Sallary> Sallary=repos.findAll();
		return Sallary;
	}

	@Override
	public Optional<Sallary> getSallaryById(int salId) {
	      System.out.println("in dao impl");
			Optional<Sallary> saldetails=repos.findById(salId);
			return saldetails;
	}

	@Override
	public Optional<ComputedSal> getComputedSalByAll(int empid, int month, int year) {
		
		Sallary salObj=repos.find(empid);
		System.out.println(salObj);
		double countDay=repos.find(empid, month, year);
		System.out.println("countday"+countDay);
		double extObj=erepos.find(empid, month, year);
		System.out.println("cost per hr:"+extObj);
		double attenObj=arepos.find(empid, month, year);
		System.out.println(attenObj);
		double attendanceAllawance=salObj.getAttendanceAllowance();
	     double hra=salObj.getHra();
		 double basic=salObj.getBasicSalary();
		 double medicalAllawance=salObj.getMedicalAllowance();
         double bonus=salObj.getBonus();	
         double perDay=salObj.getPerDay();
        
         
         double total=computeSal(extObj,attenObj,attendanceAllawance,hra,basic,medicalAllawance,bonus,perDay,month,countDay);
        
         ComputedSal salObject=new ComputedSal();
         salObject.setBasic(basic);
         salObject.setAttendanceAllawance(attendanceAllawance);
         salObject.setBonus(bonus);
         salObject.setExtraWorkSal(extObj); 
         salObject.setHra(hra);
         salObject.setMedicalAllawance(medicalAllawance);
         salObject.setTotal(total);
         salObject.setDaysPresent(countDay);
         
         System.out.println(salObject);
         return Optional.of(salObject);
         
		
		
	}

	@Override
	public double computeSal(double extObj, double attenObj, double attendanceAllawance, double hra, double basic,
			double medicalAllawance, double bonus, double perDay, int month,double countDay) {
		if((countDay>25) && (month==8))
		{
			System.out.println("int 1st");
			return extObj+attendanceAllawance+hra+basic+(countDay*perDay)+medicalAllawance+bonus;
		}
		if(countDay>25)
		{
			System.out.println("int 2st");
			return extObj+attendanceAllawance+hra+basic+(countDay*perDay)+medicalAllawance;
		}
		else
		{
			System.out.println("int 3st");
			return extObj+hra+basic+(countDay*perDay)+medicalAllawance;
		}
		
		
	}
	 
	
	
	
	
	

	
}
