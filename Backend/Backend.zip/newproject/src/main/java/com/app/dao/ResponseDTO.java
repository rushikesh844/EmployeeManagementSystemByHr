package com.app.dao;

import java.time.LocalDate;

public class ResponseDTO {
	private String mesg;
	private LocalDate ts;

	public ResponseDTO() {
		// TODO Auto-generated constructor stub
	}

	public ResponseDTO(String mesg, LocalDate ts) {
		super();
		this.mesg = mesg;
		this.ts = ts;
	}
	
	public ResponseDTO(String mesg) {
		super();
		this.mesg = mesg;
	}

	public String getMesg() {
		return mesg;
	}

	public void setMesg(String mesg) {
		this.mesg = mesg;
	}

	public LocalDate getTs() {
		return ts;
	}

	public void setTs(LocalDate ts) {
		this.ts = ts;
	}

}
