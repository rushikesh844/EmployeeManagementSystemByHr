package com.app.pojo;

public enum Gender {
	MALE, FEMALE;
}
