package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.pojo.Attendance;
import com.app.pojo.ExtraWork;
import com.app.pojo.Sallary;

public interface IAttendanceRepository extends JpaRepository<Attendance, Integer>
{
	  /*@Query(value="SELECT p FROM Attendance p where p.employee.empId=:empid and p.month=:month and p.year=:year")
       List<Attendance> find(@Param("empid") int empid,@Param("month") int month,@Param("year") int year);*/
	  
	 @Query(value="SELECT sum(v.days) from Attendance v where v.employee.empId=:empid and v.month=:month and v.year=:year")
	   double find(@Param("empid") int empid,@Param("month") int month,@Param("year") int year);
       
            
       
       
      


}
