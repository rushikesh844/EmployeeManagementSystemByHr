package com.app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.Department;

public interface IDepartmentRepository  extends JpaRepository<Department, Integer>  {
	Optional<Department> findByName(String name);
}
