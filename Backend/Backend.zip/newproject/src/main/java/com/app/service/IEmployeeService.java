package com.app.service;

import java.security.cert.PKIXRevocationChecker.Option;
import java.util.List;
import java.util.Optional;

import com.app.pojo.Attendance;
import com.app.pojo.Employee;

public interface IEmployeeService {
     
	List<Employee> findAllEmployee();
	Optional<Employee> getEmployeeById(int empid);
	Optional<Employee> updateEmployee(int empid,Employee extEmp);
	Employee addNewEmployee(Employee newEmp);
	Optional<Employee> getEmployeeByCity(String name);
	List<Attendance> getAllAttendanceById(int empid,int month,int year);
}
