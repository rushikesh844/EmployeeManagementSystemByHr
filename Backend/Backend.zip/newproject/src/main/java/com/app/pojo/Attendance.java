package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.*;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="attendanceId")
@Table(name="attendance")
public class Attendance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id",updatable = false)
	private Integer attendanceId ;
	
	@Column(length=20,name = "present")
    private String present;
	
	@Column(length=20,name = "date")
	private int date;
	
	@Column(length=20,name = "month")
	private int month;
	
    
	@Column(length=20,name = "year")
	private int year;

	@Column(length=20,name = "days")
	private int days;
	
	@Column(length=10,name = "status",columnDefinition = "TINYINT(1)")
	private boolean status;
	
	
	@ManyToOne
	@JoinColumn(name="empid")
	private Employee employee;
	
	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(Integer attendanceId) {
		this.attendanceId = attendanceId;
	}

 public String getPresent() {
		return present;
	}

	public void setPresent(String present) {
		this.present = present;
	}

	public int getDate() {
		return date;
	}

	public void setDate(int date) {
		this.date = date;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	
	
	
}
