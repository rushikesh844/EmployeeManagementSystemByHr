package com.app.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="hrId")
@Table(name="hrlogin")
public class HrLogin {
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="hrid")
	private Integer hrId;
	
    @Column(length=20,name = "fname")
	private String firstName; 
	
	@Column(length=20,name = "lname")
	private String lastName;
	
	@Column(length=20,name = "fathername")
    private String fatherName;
    
	@Column(length=30,name="email")
    private String email;
	
	@Column(length=15,name="password")
    private String password;
 
    @Column(name="role")
    @Enumerated(EnumType.STRING)
    private Role role;

    @JsonIgnore
	@OneToMany(mappedBy="hr",cascade = CascadeType.ALL)
	private List<Employee> emplist=new ArrayList<>();

	

	public HrLogin() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Integer getHrId() {
		return hrId;
	}



	public void setHrId(Integer hrId) {
		this.hrId = hrId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getFatherName() {
		return fatherName;
	}



	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public Role getRole() {
		return role;
	}



	public void setRole(Role role) {
		this.role = role;
	}



	public List<Employee> getEmplist() {
		return emplist;
	}



	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

	
	
	
	


}