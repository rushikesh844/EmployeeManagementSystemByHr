package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojo.ComputedSal;
import com.app.pojo.Sallary;
import com.app.repository.IAttendanceRepository;
@Service
@Transactional
public class IAttendanceServiceImpl implements IAttendanceService {

	@Autowired IAttendanceRepository repos;

/*@Override
	public Optional<ComputedSal>  getSalByAttendance(int empid, int month, int year) {
		double totalNoAttendance=repos.find(empid, month, year);
		System.out.println("getsal::"+totalNoAttendance);
	Sallary salobj=repos.find(empid);
		System.out.println(salobj.toString());
	    double aAllawance=salobj.getAttendanceAllowance();
	    double hra=salobj.getHra();
	    double basic=salobj.getBasicSalary();
	    double perday=salobj.getPerDay();
	    double mAllaowance=salobj.getMedicalAllowance();
	    double bonus=salobj.getBonus();
	  
	    double totalsal=ComputeSal(aAllawance,hra,perday,mAllaowance,totalNoAttendance,basic);
	    System.out.println("totalsal="+totalsal);
	    
	    ComputedSal computSalObj=new ComputedSal();
	    computSalObj.setTotal(totalsal);
	    computSalObj.setAttendanceAllawance(aAllawance);
	    computSalObj.setBasic(basic);
	    computSalObj.setHra(hra);
	    computSalObj.setBonus(bonus);
	    computSalObj.setMedicalAllawance(mAllaowance);
	    System.out.println("my final sal:::::"+computSalObj.toString());
	    return Optional.of(computSalObj);
	}

	@Override
	public double ComputeSal(double aAllawance, double hra, double perday, double mAllaowance,double totalNoAttendance,double basic) {
		if(totalNoAttendance>25)
		{
			System.out.println("in if of sal");
			return aAllawance+hra+(perday*totalNoAttendance)+mAllaowance+basic;
		}
		else
			return hra+(perday*totalNoAttendance)+mAllaowance+basic;
		
	}*/
	
	

	
	
	
	
	//@Override
	/*public List<Attendance> getAttendanceBy(int empid, int month, int year) {
		List<Attendance> attlist=repos.find(empid,month,year);
		return attlist;
	}*/

}
