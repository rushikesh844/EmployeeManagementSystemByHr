package com.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.app.pojo.ComputedSal;
import com.app.pojo.ExtraWork;

public interface IExtraWorkService {
	
	List<ExtraWork> findAllExtraWork();
    
  
}
