package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojo.HrLogin;
import com.app.repository.IHrRepository;
@Service
@Transactional
public class IHrServiceImpl implements IHrService {

	@Autowired
	private  IHrRepository repos;

	@Override
	public Optional<HrLogin> gethr(String pass) {
		System.out.println("in hr service impl");
		    Optional<HrLogin> exthr=repos.findByPassword(pass);
		    return exthr;
	}

	@Override
	public Optional<HrLogin> getHrById(int Id) {
		System.out.println("in dao hr ");
		Optional<HrLogin> existinghr=repos.findById(Id);
		return existinghr;
	}

	@Override
	public List<HrLogin> getAllHr() {
	  System.out.println("in service impls hr");
	  List<HrLogin> allhr=repos.findAll();
	  return allhr;
	}
	@Override
	public Optional<HrLogin> getHrByEmailId(String email, String pass) {
		
		return repos.findByEmailAndPassword(email, pass);
	}
	
	

	
	}


