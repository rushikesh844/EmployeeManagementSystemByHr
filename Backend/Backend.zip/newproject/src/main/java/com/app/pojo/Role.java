package com.app.pojo;

public enum Role {
	HR;
}
