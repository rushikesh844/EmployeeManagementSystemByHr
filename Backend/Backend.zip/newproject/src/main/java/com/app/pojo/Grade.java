package com.app.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="gradeId")
@Table(name="grade")
public class Grade {
	
	    @Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="gid")
		private Integer gradeId;
	    
	    @Column(name="bonus")
		private double bonus;
		
	    
	    @Column(name="grade")
	    private String grade;
	    
	    @Column(name="basicsalary")
	    private double basicSalary;
	    
	    @Column(name="mallowance")
	    private double medicalAllowance;
	    
	    @Column(name="attendanceallowance")
	    private double attendanceAllowance;
	    
	    @Column(name="perday")
	    private double perDay;
	    
	    @Column(name="hra")
	    private double hra;
	    
	    @JsonIgnore
	    @OneToMany(mappedBy ="grade",cascade = CascadeType.ALL)
		private List<Employee> emplist=new ArrayList<>();

		public Grade() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public double getAttendanceAllowance() {
			return attendanceAllowance;
		}

		public void setAttendanceAllowance(double attendanceAllowance) {
			this.attendanceAllowance = attendanceAllowance;
		}

		public double getPerDay() {
			return perDay;
		}



		public void setPerDay(double perDay) {
			this.perDay = perDay;
		}



		public double getHra() {
			return hra;
		}



		public void setHra(double hra) {
			this.hra = hra;
		}
        
		


		public double getBonus() {
			return bonus;
		}

		public void setBonus(double bonus) {
			this.bonus = bonus;
		}

		public Integer getGradeId() {
			return gradeId;
		}

		public void setGradeId(Integer gradeId) {
			this.gradeId = gradeId;
		}

		public String getGrade() {
			return grade;
		}

		public void setGrade(String grade) {
			this.grade = grade;
		}

		public double getBasicSalary() {
			return basicSalary;
		}

		public void setBasicSalary(double basicSalary) {
			this.basicSalary = basicSalary;
		}

		public double getMedicalAllowance() {
			return medicalAllowance;
		}

		public void setMedicalAllowance(double medicalAllowance) {
			this.medicalAllowance = medicalAllowance;
		}

		public List<Employee> getEmplist() {
			return emplist;
		}

		public void setEmplist(List<Employee> emplist) {
			this.emplist = emplist;
		}
		

		

}
