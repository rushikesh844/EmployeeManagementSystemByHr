package com.app.pojo;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="extraworkid")
@Table(name="extrawork")
public class ExtraWork {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "extraworkid")
	private Integer extraworkid;
	

	@ManyToOne
	@JoinColumn(name="empid")
	private Employee employee; 
	
	@Column(name="costPerDay")
	private double costPerDay;

	@Column(name="month")
	private int month;
	
	@Column(name="day")
	private int day;
	
	@Column(name="year")
	private int year;
	
	

	public ExtraWork() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Integer getExtraworkid() {
		return extraworkid;
	}



	public void setExtraworkid(Integer extraworkid) {
		this.extraworkid = extraworkid;
	}



	public Employee getEmployee() {
		return employee;
	}



	public void setEmployee(Employee employee) {
		this.employee = employee;
	}




    
	

	public int getMonth() {
		return month;
	}



	public void setMonth(int month) {
		this.month = month;
	}



	public int getDay() {
		return day;
	}



	public void setDay(int day) {
		this.day = day;
	}



	public int getYear() {
		return year;
	}



	public void setYear(int year) {
		this.year = year;
	}



	



	public double getCostPerDay() {
		return costPerDay;
	}



	public void setCostPerDay(double costPerDay) {
		this.costPerDay = costPerDay;
	}



	public void setCostPerHour(double costPerHour) {
		costPerHour = costPerHour;
	}



	@Override
	public String toString() {
		return "ExtraWork [extraworkid=" + extraworkid + ", employee=" + employee + ", costPerDay=" + costPerDay
				+ ", month=" + month + ", day=" + day + ", year=" + year + "]";
	}



	

	
	

	

}
