package com.app.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.pojo.ExtraWork;

public interface IExtraWorkRepository  extends JpaRepository<ExtraWork, Integer> {
	 
	 
	 
	 @Query(value="SELECT SUM(v.costPerDay) from ExtraWork v where v.employee.empId=:empid and v.month=:month and v.year=:year")
	 double find(@Param("empid") int empid,@Param("month") int month,@Param("year") int year);
     
	 
   
}
