package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.Leave;

public interface ILeaveRepository extends JpaRepository<Leave, Integer> {

}
