package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.pojo.ComputedSal;
import com.app.pojo.Employee;
import com.app.pojo.Sallary;

public interface ISallaryService {

	List<Sallary> findAllSalaryDetails();
	Optional<Sallary> getSallaryById(int salId);
	Optional<ComputedSal> getComputedSalByAll(int empid,int month,int year);
	double computeSal(double extObj,double attenObj,double attendanceAllawance,double hra,double basic,double medicalAllawance,
			     double bonus, double perDay,int month,double countDay);
}
