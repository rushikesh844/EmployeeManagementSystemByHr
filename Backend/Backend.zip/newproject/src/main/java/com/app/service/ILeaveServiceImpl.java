package com.app.service;

public class ILeaveServiceImpl implements ILeaveService {

}
