package com.app.pojo;

public class ComputedSal {
	
	private double total;
	
	private double hra;
	private double basic;
	
   private double medicalAllawance;
   private double attendanceAllawance;
   private double bonus;
   
   private double extraWorkSal;
   
   private double daysPresent;
   
   
public ComputedSal() {
	super();
	// TODO Auto-generated constructor stub
}
public double getTotal() {
	return total;
}
public void setTotal(double total) {
	this.total = total;
}
public double getHra() {
	return hra;
}
public void setHra(double hra) {
	this.hra = hra;
}
public double getBasic() {
	return basic;
}
public void setBasic(double basic) {
	this.basic = basic;
}
public double getMedicalAllawance() {
	return medicalAllawance;
}
public void setMedicalAllawance(double medicalAllawance) {
	this.medicalAllawance = medicalAllawance;
}
public double getAttendanceAllawance() {
	return attendanceAllawance;
}
public void setAttendanceAllawance(double attendanceAllawance) {
	this.attendanceAllawance = attendanceAllawance;
}
public double getBonus() {
	return bonus;
}
public void setBonus(double bonus) {
	this.bonus = bonus;
}
public double getExtraWorkSal() {
	return extraWorkSal;
}
public void setExtraWorkSal(double extraWorkSal) {
	this.extraWorkSal = extraWorkSal;
}
public double getDaysPresent() {
	return daysPresent;
}
public void setDaysPresent(double daysPresent) {
	this.daysPresent = daysPresent;
}
@Override
public String toString() {
	return "ComputedSal [total=" + total + ", hra=" + hra + ", basic=" + basic + ", medicalAllawance="
			+ medicalAllawance + ", attendanceAllawance=" + attendanceAllawance + ", bonus=" + bonus + ", extraWorkSal="
			+ extraWorkSal + ", daysPresent=" + daysPresent + "]";
}



   
   



}
