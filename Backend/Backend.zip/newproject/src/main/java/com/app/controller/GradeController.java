package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojo.Department;
import com.app.pojo.Grade;
import com.app.repository.IEmployeeRepository;
import com.app.service.IGradeService;

@RestController
@RequestMapping("/grade")
@CrossOrigin(origins = "http://localhost:4200")
public class GradeController {

	
	@Autowired
	private IEmployeeRepository dao;
	
	@Autowired
	private IGradeService service;
	
	
	@GetMapping
	public ResponseEntity<?> getallGrade()
	{
		System.out.println("controller");
		List<Grade> gradelist=service.findAllGrade();
		if(gradelist.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);		
		return new ResponseEntity<>(gradelist,HttpStatus.OK);		
	}
	
	@GetMapping("/{gradeid}")
	public ResponseEntity<?> getDeptDetails(@PathVariable int gradeid) {
		System.out.println("in get dept dtls " + gradeid);
		Optional<Grade> optional = service.getGradetById(gradeid);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
	//	ErrorResponse resp = new ErrorResponse("dept Id Invalid", "Must Supply valid dept Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/addgrade")
	public ResponseEntity<?> addNewGrade(@RequestBody Grade newGrade)
	{
		System.out.println("in employee controller");
		Grade newGradeobj=(Grade) service.addNewGrade(newGrade);
		return new ResponseEntity<>(newGradeobj,HttpStatus.OK);
	}
	
}
