package com.app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.HrLogin;


public interface IHrRepository extends JpaRepository<HrLogin, Integer> {
	 Optional<HrLogin> findByPassword(String pass);
	 Optional<HrLogin> findByEmailAndPassword(String email, String pass);
}
