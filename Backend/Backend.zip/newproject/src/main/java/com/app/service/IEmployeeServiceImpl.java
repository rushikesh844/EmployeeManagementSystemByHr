package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.pojo.Attendance;
import com.app.pojo.Employee;
import com.app.pojo.HrLogin;
import com.app.repository.*;
@Service
@Transactional
public class IEmployeeServiceImpl implements IEmployeeService {
//add dependecy of dao
	@Autowired
	private IEmployeeRepository repos;

  

	@Override
	public List<Employee> findAllEmployee() {
		System.out.println("in service impl");
		List<Employee> emplist=repos.findByAll();
		return emplist;
	}



	@Override
	public Optional<Employee> getEmployeeById(int empid) {
	      System.out.println("in dao impl");
			Optional<Employee> emp=repos.findById(empid);
			return emp;
	}



	@Override
	public Employee  addNewEmployee(Employee newEmp) {
		System.out.println("service impl of employee");
		return repos.save(newEmp);
		
	}



	@Override
	public Optional<Employee> updateEmployee(int empid,Employee extEmp) {
// TODO Auto-generated method stub
      Optional<Employee> emp=repos.findById(empid);
		if(emp.isPresent())
		{
			Employee existingemp=emp.get();
			existingemp.setFirstName(extEmp.getFirstName());;
			existingemp.setCity(extEmp.getCity());
			existingemp.setDateOfBirth(extEmp.getDateOfBirth());
			existingemp.setDepartment(extEmp.getDepartment());
			existingemp.setFatherName(extEmp.getFatherName());
			existingemp.setLastName(extEmp.getLastName());
			existingemp.setGender(extEmp.getGender());
			existingemp.setMobNo(extEmp.getMobNo());
			existingemp.setMaritalStatus(extEmp.isMaritalStatus());
			existingemp.setJoinDate(extEmp.getJoinDate());
			
		
			return emp;
		
			
		}
		throw new ResourceNotFoundException("no product found");
		
	}



	@Override
	public Optional<Employee> getEmployeeByCity(String name) {
		System.out.println("in hr service impl");
	    Optional<Employee> emp=repos.findByCity(name);
	    return emp;
	}



	@Override
	public List<Attendance> getAllAttendanceById(int empid, int month, int year) {
		 
		List<Attendance> alist=repos.find(empid,month,year);
		return alist;
		
	}

	



	
	

	
	
	
	
}
