package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.Grade;

public interface IGradeRepository extends JpaRepository<Grade, Integer> {

}
