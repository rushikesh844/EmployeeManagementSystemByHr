package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.pojo.Sallary;

public interface ISallaryRepository extends JpaRepository<Sallary, Integer> {
	
	@Query(value="SELECT s from Sallary s where s.employee.empId=:empid")
    Sallary find(@Param("empid") int empid);
	
	@Query(value="SELECT sum(v.days) from Attendance v where v.employee.empId=:empid and v.month=:month and v.year=:year")
	   double find(@Param("empid") int empid,@Param("month") int month,@Param("year") int year);

}
