package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="sallaryId")
@Table(name = "sallary")
public class Sallary {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sallaryid", updatable = false)
	private Integer sallaryId;
	
	
	@OneToOne
	@JoinColumn(name="empid")
	private Employee employee;
	
	@Column(name="basic")	
	private double basicSalary;

	@Column(name="hra")	
	private double hra;

	@Column(name="attendanceallowance")	
	private double attendanceAllowance;

	@Column(name="medicalAllowance")	
	private double medicalAllowance;

	@Column(name="bonus")
	private double bonus;
	
	@Column(name = "perday")
	private double perDay;
	
	@Column(name="adharno")
	private String adharno; 
	
	@Column(name="panno")
	private String panno; 
	
	@Column(name="pfno")
	private long pfno; 
	
	@Column(name="accountno")
	private String accountno;
	
	public Sallary() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getSallaryId() {
		return sallaryId;
	}

	public void setSallaryId(Integer sallaryId) {
		this.sallaryId = sallaryId;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public double getHra() {
		return hra;
	}

	public void setHra(double hra) {
		this.hra = hra;
	}

	public double getAttendanceAllowance() {
		return attendanceAllowance;
	}

	public void setAttendanceAllowance(double attendanceAllowance) {
		this.attendanceAllowance = attendanceAllowance;
	}

	public double getMedicalAllowance() {
		return medicalAllowance;
	}

	public void setMedicalAllowance(double medicalAllowance) {
		this.medicalAllowance = medicalAllowance;
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public double getPerDay() {
		return perDay;
	}

	public void setPerDay(double perDay) {
		this.perDay = perDay;
	}

	public String getAdharno() {
		return adharno;
	}

	public void setAdharno(String adharno) {
		this.adharno = adharno;
	}

	public String getPanno() {
		return panno;
	}

	public void setPanno(String panno) {
		this.panno = panno;
	}

	public long getPfno() {
		return pfno;
	}

	public void setPfno(long pfno) {
		this.pfno = pfno;
	}

	public String getAccountno() {
		return accountno;
	}

	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}
	
	

	@Override
	public String toString() {
		return "Sallary [sallaryId=" + sallaryId + ", basicSalary=" + basicSalary + ", hra=" + hra + ", attendanceAllowance="
				+ attendanceAllowance + ", medicalAllowance=" + medicalAllowance + ", bonus=" + bonus + ", perDay="
				+ perDay + ", adharno=" + adharno + ", panno=" + panno + ", pfno=" + pfno + ", accountno=" + accountno
				+ "]";
	}
	
	
	
	
	


}
