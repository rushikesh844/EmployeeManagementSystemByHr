package com.app.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.dao.ResponseDTO;
import com.app.dto.ErrorResponse;
import com.app.pojo.Attendance;
import com.app.pojo.Department;
import com.app.pojo.Employee;
import com.app.pojo.Grade;
import com.app.pojo.HrLogin;
import com.app.repository.IEmployeeRepository;
import com.app.service.IEmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/employee")
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController {

	//add dependency
	@Autowired
	private IEmployeeService service;
	@Autowired
	private IEmployeeRepository dao;
	//private EmployeeRepository dao;
	@GetMapping
	public ResponseEntity<?> getallemployee()
	{
		System.out.println("controller");
		List<Employee> emplist=service.findAllEmployee();
		if(emplist.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);		
		return new ResponseEntity<>(emplist,HttpStatus.OK);		
	}
	
	@GetMapping("/{emp_id}")
	public ResponseEntity<?> getEmpDetails(@PathVariable int emp_id) {
		System.out.println("in get emp dtls " + emp_id);
		Optional<Employee> optional = service.getEmployeeById(emp_id);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
		ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/update")
	public ResponseEntity<?> addEmp(@RequestBody Employee newEmp)
	{
		System.out.println("in employee controller");
		Employee newemployee=(Employee) service.addNewEmployee(newEmp);
		return new ResponseEntity<>(newemployee,HttpStatus.OK);
	}
	@PostMapping("/add")
	public ResponseDTO addEmployee(@RequestParam String dtls,@RequestParam String grade, @RequestParam MultipartFile imageFile,@RequestParam String department,@RequestParam String hr) {
		try {
			
			Employee emp= new ObjectMapper().readValue(dtls, Employee.class);
			Department deptid= new ObjectMapper().readValue(department, Department.class);
			Grade gradeid= new ObjectMapper().readValue(grade, Grade.class);
			HrLogin hrid=new ObjectMapper().readValue(hr, HrLogin.class);
			emp.setImageurl(imageFile.getBytes());
			emp.setImageContentType(imageFile.getContentType());
			emp.setDepartment(deptid);
			emp.setHr(hrid);
			emp.setGrade(gradeid);
		
			
			dao.save(emp);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseDTO("File uploaded :" + imageFile.getOriginalFilename() + " @ ",LocalDate.now());
	}
	
	
	@PutMapping("/{empId}")
	public ResponseEntity<?> updateEmpDetails(@PathVariable int empId, @RequestBody Employee emp) {
		System.out.println("in update emp " + empId + " " + emp);
		// check if emp exists
		Optional<Employee> extemp=service.updateEmployee(empId,emp);
			// update detached POJO
		if(extemp.isPresent())
			return new ResponseEntity<>(extemp, HttpStatus.OK);
			// save or update (insert: transient(value of ID : default
			// or non default value BUT existing on DB -- update
	  throw new ResourceNotFoundException("Emp ID Invalid");
	  }
	
	//delete employee
	@DeleteMapping("/{empId}")
	public ResponseEntity<?> deleteEmpDetails(@PathVariable int empId) {
		System.out.println("in delete emp " + empId);
		// check if emp exists
		Optional<Employee> optional =dao.findById(empId);
		if (optional.isPresent()) {
			dao.deleteById(empId);
			return new ResponseEntity<>(empId, HttpStatus.OK);
		} 
		else {
			  ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");}
		     throw new ResourceNotFoundException("Emp ID Invalid : rec deletion failed");
		//	throw new RuntimeException("my own err mesg");
		

	}
	
	
	
	@GetMapping("/city/{cityname}")
	public ResponseEntity<?> getEmpDetailsbyCity(@PathVariable String cityname) {
		System.out.println("in get emp dtls " + cityname);
		Optional<Employee> optional = service.getEmployeeByCity(cityname);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
		ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	@GetMapping("/email/{emailId}")
	public ResponseEntity<?> getEmpDetailsbyEmail(@PathVariable String emailId) {
		System.out.println("in get emp dtls " +emailId);
		//Optional<Employee> optional = service.getEmployeeByCity(cityname);
		//if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
		Optional<Employee> optional=dao.findByEmail(emailId);
		if(optional.isPresent())	   
		      return ResponseEntity.ok(optional.get());
		// invalid id
		ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	
	@GetMapping("/{empid}"+"/{month}"+"/{year}")
	public ResponseEntity<?> getAttendanceById(@PathVariable int empid,@PathVariable int month,@PathVariable int year)
	{
		System.out.println("in emp cntroller");
	   List<Attendance> listAttendance=service.getAllAttendanceById(empid,month,year);
	   if(listAttendance.isEmpty())
	   {
		   ErrorResponse resp = new ErrorResponse(" Invalid data", "Must Supply valid data");
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	   }
		return new ResponseEntity<>(listAttendance,HttpStatus.OK);		
	}
	
	@GetMapping("/getbydepartmentid/{deptid}")
	public ResponseEntity<?> getAllEmpByDept(@PathVariable int deptid)
	{
		List<Employee> emplist=dao.find(deptid);
		if(emplist.isEmpty())
		{
			 ErrorResponse resp = new ErrorResponse(" Invalid data", "Must Supply valid data");
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	return new ResponseEntity<>(emplist,HttpStatus.OK);	
	}
	
}
