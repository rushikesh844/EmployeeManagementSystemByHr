package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="leaveid")
@Table(name="leavetable")
public class Leave {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "leaveid")
	private Integer leaveid;
	
	@Column(name = "fromdate")
	private LocalDate fromDate;
	
	@Column(name = "todate")
	private LocalDate toDate;
	
	
	@Column(length=20,name = "leavetype")
	private String leavetype;
	
	@Column(name="balanceleave")
	private int balanceleave;
	
	
	@ManyToOne
	@JoinColumn(name="empid")
	private Employee employee;

	public Leave() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getLeaveid() {
		return leaveid;
	}

	public void setLeaveid(Integer leaveid) {
		this.leaveid = leaveid;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}

	public int getBalanceleave() {
		return balanceleave;
	}

	public void setBalanceleave(int balanceleave) {
		this.balanceleave = balanceleave;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	

	
	

	
	
}
