package com.app.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojo.Attendance;
import com.app.pojo.Employee;
public interface IEmployeeRepository extends JpaRepository<Employee, Integer> {
	Optional<Employee> findByCity(String cname);
	@Query(value = "SELECT * FROM EMPLOYEE", nativeQuery = true)
	  List<Employee> findByAll();
	Optional<Employee> findByEmail(String email);
	
	@Query(value="select a from Attendance a where a.employee.empId=:empid and a.month=:month and a.year=:year")
	 List<Attendance> find(int empid,int month,int year);
	
	@Query(value="select e from Employee e where e.department.deptid=:deptid")
	List<Employee> find(int deptid);
	
}
