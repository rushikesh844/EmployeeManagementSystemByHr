package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.cust_excs.ResourceNotFoundException;

import com.app.pojo.Department;
import com.app.pojo.Employee;
import com.app.pojo.HrLogin;
import com.app.repository.IDepartmentRepository;
import com.app.service.IDepartmentService;

@RestController
@RequestMapping("/department")
@CrossOrigin(origins = "http://localhost:4200")
public class DepartmentController {
	
	@Autowired
	private IDepartmentService service;
	@Autowired
   private IDepartmentRepository dao;
	//get all details
	@GetMapping
	public ResponseEntity<?> getAllDepartment()
	{
		System.out.println("controller");
		List<Department> deptlist=service.findAllDepartment();
		if(deptlist.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);		
		return new ResponseEntity<>(deptlist,HttpStatus.OK);		
		
	}
	//get by name
	@GetMapping("/{dept_id}")
	public ResponseEntity<?> getDeptDetails(@PathVariable int dept_id) {
		System.out.println("in get dept dtls " + dept_id);
		Optional<Department> optional = service.getDepartmentById(dept_id);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
	//	ErrorResponse resp = new ErrorResponse("dept Id Invalid", "Must Supply valid dept Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	//delete department
	@DeleteMapping("/{deptId}")
	public ResponseEntity<?> deleteEmpDetails(@PathVariable int deptId) {
		System.out.println("in delete emp " + deptId);
		// check if emp exists
		Optional<Department> optional =dao.findById(deptId);
		if (optional.isPresent()) {
			dao.deleteById(deptId);
			return new ResponseEntity<>(deptId, HttpStatus.OK);
		} 
		else
			 throw new ResourceNotFoundException("dept ID Invalid : rec deletion failed");
		//	throw new RuntimeException("my own err mesg");

	}
	//by name
	@PostMapping("/{name}")
	public ResponseEntity<?> getDepartmentDetails(@PathVariable String name) {
		System.out.println("in get dept dtls " + name);
		Optional<Department> optional = service.getDepartmentByName(name);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
		//ErrorResponse resp = new ErrorResponse("dept Id Invalid", "Must Supply valid dept Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
/// add new department
	@PostMapping
	public ResponseEntity<?> addNewDept(@RequestBody Department newDept)
	{
		System.out.println("in employee controller");
		Department newDepartment=(Department) service.addNewDepartment(newDept);
		return new ResponseEntity<>(newDepartment,HttpStatus.OK);
	}
	//update department
	@PutMapping("/{deptId}")
	public ResponseEntity<?> updateEmpDetails(@PathVariable int deptId, @RequestBody Department dept) {
		System.out.println("in update emp " + deptId + " " +dept );
		// check if emp exists
		Optional<Department> extdept=service.updateDepartment(deptId,dept);
			// update detached POJO
		if(extdept.isPresent())
			return new ResponseEntity<>(extdept, HttpStatus.OK);
			// save or update (insert: transient(value of ID : default
			// or non default value BUT existing on DB -- update
	  throw new ResourceNotFoundException("Emp ID Invalid");
	  }
	
	
}
