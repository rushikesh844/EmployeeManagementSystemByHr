package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.pojo.HrLogin;

public interface IHrService {
	Optional<HrLogin> gethr(String pass);
    Optional<HrLogin> getHrById(int Id);
    List<HrLogin> getAllHr();
    Optional<HrLogin> getHrByEmailId(String email, String pass);
}
