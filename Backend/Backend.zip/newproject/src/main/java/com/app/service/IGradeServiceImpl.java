package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojo.Employee;
import com.app.pojo.Grade;
import com.app.repository.IGradeRepository;
import com.app.repository.IHrRepository;

@Service
@Transactional
public class IGradeServiceImpl implements IGradeService{

	@Autowired
	private IGradeRepository repos;
	
	
	@Override
	public List<Grade> findAllGrade() {
		// TODO Auto-generated method stub
		System.out.println("in service impl");
		List<Grade> gradelist=repos.findAll();
		return gradelist;
		
		
	}


	@Override
	public Optional<Grade> getGradetById(int id) {
		System.out.println("in service impl");
		Optional<Grade>  gradeid=repos.findById(id);
		return gradeid;
	}
	
	@Override
	public Grade addNewGrade(Grade newgrade) {
		System.out.println("service impl of grade");
		return repos.save(newgrade);
		
	}
	
	
	
}
