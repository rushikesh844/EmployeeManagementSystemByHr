package com.app.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.app.pojo.HrLogin;
import com.app.repository.IEmployeeRepository;
import com.app.repository.IHrRepository;
import com.app.pojo.Employee;
import com.app.service.IHrService;

@RestController
@RequestMapping("/hr")
@CrossOrigin(origins = "http://localhost:4200")
public class HrController {
	
	
	@Autowired
	private IHrService service;
	//private IHrRepository respos;
	
	@GetMapping
	public ResponseEntity<?> getAllHrDetails() {
		List<HrLogin> hrlist = service.getAllHr();
	//	return new ResponseEntity<>(emps, HttpStatus.OK);
		return ResponseEntity.ok(hrlist);//sts code : 200 , body : list of emps
	}
	@PostMapping("/login")
	public Optional<HrLogin> loginHr(@RequestBody HrLogin hrLogin) throws Exception
	{
		String emailId = hrLogin.getEmail();
		String password = hrLogin.getPassword();
		Optional<HrLogin> loginObj=null;
		if(emailId != null && password != null)
		{
			loginObj=service.getHrByEmailId(emailId, password);
		}
		if(loginObj == null)
		{
			throw new Exception("Bad Credential");
		}
		return loginObj;
		
	}

	@GetMapping("/{hr_id}")
	public ResponseEntity<?> getHrDetails(@PathVariable int hr_id) {
		System.out.println("in get emp dtls " + hr_id);
		Optional<HrLogin> optional = service.getHrById(hr_id);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
		//ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
    
}
