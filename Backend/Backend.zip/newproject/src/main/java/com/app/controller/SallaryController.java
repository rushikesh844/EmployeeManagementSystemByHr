package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojo.ComputedSal;
import com.app.pojo.Employee;
import com.app.pojo.Sallary;
import com.app.repository.ISallaryRepository;
import com.app.service.ISallaryService;

@RestController
@RequestMapping("/sallary")
@CrossOrigin(origins = "http://localhost:4200")
public class SallaryController {

	@Autowired
	private ISallaryService service;
	
	@Autowired
	private ISallaryRepository dao;
	
	/*@GetMapping
	public ResponseEntity<?> getAllSallaryDetails()
	{
		System.out.println("controller");
	  List<Sallary> sallist=service.findAllSalaryDetails();
		if(sallist.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);		
		return new ResponseEntity<>(sallist,HttpStatus.OK);		
	}*/
	@GetMapping
	public ResponseEntity<?> getAllSallaryDetails()
	{
		System.out.println("controller");
	  List<Sallary> sallist=dao.findAll();
			return ResponseEntity.ok(sallist);		
	}
	
	@GetMapping("/{sallaryId}")
	public ResponseEntity<?> getEmpDetails(@PathVariable int sallaryId) {
		System.out.println("in get emp sal id dtls " + sallaryId);
		Optional<Sallary> optional = service.getSallaryById(sallaryId);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
		//ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/addsal")
	public ResponseEntity<?> addEmp(@RequestBody Sallary newSal)
	{
		System.out.println("in Sallary controller");
		Sallary sal=dao.save(newSal);
		return new ResponseEntity<>(newSal,HttpStatus.OK);
	}
	
	@GetMapping("/{empid}"+"/{month}"+"/{year}")
	public ResponseEntity<?> getsalary(@PathVariable int empid,@PathVariable int month,@PathVariable int year)
	{
		System.out.println("in get dept dtls " + empid+" "+month+" "+year);
	   
		
		Optional<ComputedSal> obj = service.getComputedSalByAll(empid,month,year);
		/*if (optional)
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			*/
		return ResponseEntity.ok(obj);
		// invalid id
	//	ErrorResponse resp = new ErrorResponse("dept Id Invalid", "Must Supply valid dept Id");*/
		
		
	}
}
