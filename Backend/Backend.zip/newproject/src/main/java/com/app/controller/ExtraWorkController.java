package com.app.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.pojo.ComputedSal;
import com.app.pojo.ExtraWork;
import com.app.repository.IExtraWorkRepository;
import com.app.service.IExtraWorkService;

@RestController
@RequestMapping("/extrawork")
@CrossOrigin(origins = "http://localhost:4200")
public class ExtraWorkController {

	@Autowired
	private IExtraWorkService service;
	
	@Autowired
	private IExtraWorkRepository dao;
	
	//all extra work details
	@GetMapping
	public ResponseEntity<?> getAllExtraWorks()
	{
		System.out.println("controller");
		List<ExtraWork> extraworklist=service.findAllExtraWork();
		if(extraworklist.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);		
		return new ResponseEntity<>(extraworklist,HttpStatus.OK);		
		
	}
	
	
	@PostMapping("/addextrawork")
	public ResponseEntity<?> addExtraWorkDetails(@RequestBody ExtraWork extObj)
	{
		return new ResponseEntity<>(dao.save(extObj), HttpStatus.CREATED);
	}
	

	
	
}
