package com.app.pojo;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="deptid")
@Table(name="department")
public class Department {

	@Id
	@Column(name="deptid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer deptid;
	
	@Column(length=25,name = "deptname")
	private String name;
	
    @JsonIgnore
	@OneToMany(mappedBy="department",cascade = CascadeType.ALL)
	private List<Employee> emplist=new ArrayList<>();

	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Integer getDeptid() {
		return deptid;
	}


	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Employee> getEmplist() {
		return emplist;
	}


	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

}


