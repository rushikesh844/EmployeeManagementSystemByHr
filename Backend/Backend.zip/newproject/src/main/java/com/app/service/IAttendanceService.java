package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.pojo.Attendance;
import com.app.pojo.ComputedSal;

public interface IAttendanceService {
	//List<Attendance> getAttendanceBy(int empid, int month, int year);
	//Optional<ComputedSal> getSalByAttendance(int empid, int month, int year);
//double ComputeSal(double aAllaowance ,double hra,double perday,double mAllaowance,double getsal,double basic);
}
