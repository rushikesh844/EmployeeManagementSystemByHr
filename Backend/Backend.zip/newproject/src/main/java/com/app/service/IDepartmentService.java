package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.pojo.Department;
import com.app.pojo.Employee;


public interface IDepartmentService {

	List<Department> findAllDepartment();
	Optional<Department> getDepartmentById(int empid);
	Optional<Department> getDepartmentByName(String deptName);
	Department addNewDepartment(Department newDept);
	Optional<Department> updateDepartment(int deptId,Department extDept);
}
