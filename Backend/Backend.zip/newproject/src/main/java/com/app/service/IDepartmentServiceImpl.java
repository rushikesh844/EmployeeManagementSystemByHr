package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.pojo.Department;
import com.app.pojo.Employee;
import com.app.pojo.HrLogin;
import com.app.repository.IDepartmentRepository;

@Service
@Transactional
public class IDepartmentServiceImpl implements IDepartmentService {

	@Autowired
	private IDepartmentRepository repos;

	@Override
	public List<Department> findAllDepartment() {
		System.out.println("in service impl");
		List<Department> deptlist=repos.findAll();
		return deptlist;
	}

	@Override
	public Optional<Department> getDepartmentById(int empid) {
		 System.out.println("in service impl");
			Optional<Department> dept=repos.findById(empid);
			return dept;
	}

	@Override
	public Optional<Department> getDepartmentByName(String deptName) {
		System.out.println("in service impl");
	    Optional<Department> dept=repos.findByName(deptName);
	    return dept;
	}

	@Override
	public Department addNewDepartment(Department newDept) {
		System.out.println("service impl of employee");
		return repos.save(newDept);
	}

	@Override
	public Optional<Department> updateDepartment(int deptId, Department extDept) {
		// TODO Auto-generated method stub
		Optional<Department> dept=repos.findById(deptId);
		if(dept.isPresent())
		{
			Department existingdept=dept.get();
			existingdept.setName(extDept.getName());
			
			return Optional.ofNullable(existingdept);
		}
		throw new ResourceNotFoundException("no product found");
	}
	
	
}
	
	
	

