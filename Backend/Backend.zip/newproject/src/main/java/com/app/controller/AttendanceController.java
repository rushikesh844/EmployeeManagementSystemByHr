package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojo.*;
import com.app.repository.IAttendanceRepository;
import com.app.repository.IEmployeeRepository;
import com.app.service.IAttendanceService;
import com.app.service.IEmployeeService;

@RestController
@RequestMapping("/attendance")
@CrossOrigin(origins = "http://localhost:4200")
public class AttendanceController {

	@Autowired
	private IAttendanceService service;
	@Autowired
	private IAttendanceRepository dao;
	
	
/*@GetMapping("/{empid}"+"/{month}"+"/{year}")
	public ResponseEntity<?> getDeptDetails(@PathVariable int empid,@PathVariable int month,@PathVariable int year) {
		System.out.println("in get dept dtls " + empid+" "+month+" "+year);
		List<Attendance> optional = service.getAttendanceBy(empid,month,year);
		if (optional.isEmpty())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			
		return ResponseEntity.ok(optional);
		// invalid id
	//	ErrorResponse resp = new ErrorResponse("dept Id Invalid", "Must Supply valid dept Id");*/
		
	//}
	
	@GetMapping("/{empid}"+"/{month}"+"/{year}")
	public ResponseEntity<?> getsalary(@PathVariable int empid,@PathVariable int month,@PathVariable int year)
	{
		System.out.println("in get dept dtls " + empid+" "+month+" "+year);
	   
		
		//Optional<ComputedSal> obj = service.getSalByAttendance(empid,month,year);
		/*if (optional)
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			*/
		//return ResponseEntity.ok(obj);
		// invalid id
	//	ErrorResponse resp = new ErrorResponse("dept Id Invalid", "Must Supply valid dept Id");*/
		return null;
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

	
}
