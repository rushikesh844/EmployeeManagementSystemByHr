package com.app.pojo;

import java.sql.Blob;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
//@JsonIdentityInfo(generator =ObjectIdGenerators.PropertyGenerator.class,property="empId")
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "empid",updatable = false)
	private Integer empId ;

	@Column(length=20,name = "fname")
	private String firstName; 
	
	@Column(length=20,name = "lname")
	private String lastName;
	
	@Column(length=20,name = "fathername")
    private String fatherName;
	
	@Column(name="age")
	private int age;
	
	@Column(name="mobno") 
	private String mobNo;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name = "dob")
	private LocalDate dateOfBirth; 
	
	@Column(length=30,name="email")
	private String email;
	
	@Column(name="gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	@Column(name = "imageurl")
	@Lob
	private byte[] imageurl;
	
	@Column(length = 30)
	private String imageContentType;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name = "joindate")
	private LocalDate joinDate; 
	
	@Column(name="city")
	private String city;
	
	@Column(length=20,name = "mstatus",columnDefinition = "TINYINT(1)")
	private boolean maritalStatus; 
	
	@ManyToOne
	@JoinColumn(name="hrid")
	private HrLogin hr;
	
	@ManyToOne
	@JoinColumn(name="deptid")
	private Department department;
	
	@JsonIgnore
	@OneToOne(mappedBy="employee",cascade = CascadeType.ALL)
	private Sallary salary;
	
	   @JsonIgnore
	@OneToMany(mappedBy = "employee",cascade = CascadeType.ALL)
	private List<Attendance> attendance=new ArrayList<>();
	   @JsonIgnore
	@OneToMany(mappedBy = "employee",cascade = CascadeType.ALL)
	private List<Leave> leaveList=new ArrayList<>();
	
	   @JsonIgnore
	@OneToMany(mappedBy = "employee",cascade = CascadeType.ALL)
	private List<ExtraWork> extWork=new ArrayList<>();
	
	
	
	@ManyToOne
	@JoinColumn(name="grade")
	 private Grade grade;
	

	public Employee() {
		super();
		
	}
 
	
	
	
	

	public Employee(Integer empId, String firstName, String lastName, String fatherName, int age, String mobNo,
			LocalDate dateOfBirth, String email, Gender gender, byte[] imageurl, String imageContentType,
			LocalDate joinDate, String city, boolean maritalStatus) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.fatherName = fatherName;
		this.age = age;
		this.mobNo = mobNo;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.gender = gender;
		this.imageurl = imageurl;
		this.imageContentType = imageContentType;
		this.joinDate = joinDate;
		this.city = city;
		this.maritalStatus = maritalStatus;
	}






	public Integer getEmpId() {
		return empId;
	}
	


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public void setEmpId(Integer empId) {
		this.empId = empId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getFatherName() {
		return fatherName;
	}


	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}


	public String getMobNo() {
		return mobNo;
	}


	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}


	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Gender getGender() {
		return gender;
	}


	public void setGender(Gender gender) {
		this.gender = gender;
	}

   	public byte[] getImageurl() {
		return imageurl;
	}


	public void setImageurl(byte[] imageurl) {
		this.imageurl = imageurl;
	}


	public String getImageContentType() {
		return imageContentType;
	}


	public void setImageContentType(String imageContentType) {
		this.imageContentType = imageContentType;
	}


	public LocalDate getJoinDate() {
		return joinDate;
	}


	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public boolean isMaritalStatus() {
		return maritalStatus;
	}


	public void setMaritalStatus(boolean maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	

	public HrLogin getHr() {
		return hr;
	}


	public void setHr(HrLogin hr) {
		this.hr = hr;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	public Sallary getSalary() {
		return salary;
	}


	public void setSalary(Sallary salary) {
		this.salary = salary;
	}


	public List<Attendance> getAttendance() {
		return attendance;
	}


	public void setAttendance(List<Attendance> attendance) {
		this.attendance = attendance;
	}


	public List<Leave> getLeaveList() {
		return leaveList;
	}


	public void setLeaveList(List<Leave> leaveList) {
		this.leaveList = leaveList;
	}


	public List<ExtraWork> getExtWork() {
		return extWork;
	}


	public void setExtWork(List<ExtraWork> extWork) {
		this.extWork = extWork;
	}


	public Grade getGrade() {
		return grade;
	}


	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	
	
}
