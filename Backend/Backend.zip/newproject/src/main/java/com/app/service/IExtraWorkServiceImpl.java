package com.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojo.Employee;
import com.app.pojo.ExtraWork;
import com.app.repository.IExtraWorkRepository;
@Service
@Transactional
public class IExtraWorkServiceImpl implements IExtraWorkService {

	//depnedancy
	@Autowired
	private IExtraWorkRepository repos;
	
	@Override
	public List<ExtraWork> findAllExtraWork() {
		System.out.println("in service impl");
		List<ExtraWork> extraworklist=repos.findAll();
		return extraworklist;
	}

	

	
	
	
	

	

	
	
}
